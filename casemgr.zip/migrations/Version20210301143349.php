<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20210301143349 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('DROP TABLE IF EXISTS shared_field');
        $this->addSql('CREATE TABLE shared_field (id INT AUTO_INCREMENT NOT NULL, form_id INT NOT NULL, field_name VARCHAR(50) NOT NULL, read_only TINYINT(1) NOT NULL DEFAULT 0, source_form_id INT NOT NULL, source_field_name VARCHAR(50) NOT NULL, source_form_data VARCHAR(10) NOT NULL, source_field_function VARCHAR(10) DEFAULT NULL, source_form_data_range VARCHAR(50) DEFAULT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET UTF8 COLLATE `UTF8_unicode_ci` ENGINE = InnoDB');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('DROP TABLE shared_field');
    }
}
