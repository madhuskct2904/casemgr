$(document).ready(function() {
	$('[data-jqtable]').jqtable();
})
