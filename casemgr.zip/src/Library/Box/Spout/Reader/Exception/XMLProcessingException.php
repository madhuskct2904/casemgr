<?php

namespace App\Library\Box\Spout\Reader\Exception;

/**
 * Class XMLProcessingException
 *
 * @package App\Library\Box\Spout\Reader\Exception
 */
class XMLProcessingException extends ReaderException
{
}
