<?php

namespace App\Library\Box\Spout\Reader\Exception;

/**
 * Class IteratorNotRewindableException
 *
 * @api
 * @package App\Library\Box\Spout\Reader\Exception
 */
class IteratorNotRewindableException extends ReaderException
{
}
