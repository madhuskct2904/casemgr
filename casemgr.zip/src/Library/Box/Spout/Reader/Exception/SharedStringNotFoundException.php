<?php

namespace App\Library\Box\Spout\Reader\Exception;

/**
 * Class SharedStringNotFoundException
 *
 * @api
 * @package App\Library\Box\Spout\Reader\Exception
 */
class SharedStringNotFoundException extends ReaderException
{
}
