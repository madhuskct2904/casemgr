<?php

namespace App\Library\Box\Spout\Reader\Exception;

/**
 * Class ReaderNotOpenedException
 *
 * @api
 * @package App\Library\Box\Spout\Reader\Exception
 */
class ReaderNotOpenedException extends ReaderException
{
}
