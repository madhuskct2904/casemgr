<?php

namespace App\Library\Box\Spout\Reader\Exception;

/**
 * Class NoSheetsFoundException
 *
 * @api
 * @package App\Library\Box\Spout\Reader\Exception
 */
class NoSheetsFoundException extends ReaderException
{
}
