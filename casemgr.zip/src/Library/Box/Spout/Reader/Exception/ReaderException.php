<?php

namespace App\Library\Box\Spout\Reader\Exception;

use App\Library\Box\Spout\Common\Exception\SpoutException;

/**
 * Class ReaderException
 *
 * @package App\Library\Box\Spout\Reader\Exception
 * @abstract
 */
abstract class ReaderException extends SpoutException
{
}
