<?php

namespace App\Library\Box\Spout\Common\Exception;

/**
 * Class UnsupportedTypeException
 *
 * @api
 * @package App\Library\Box\Spout\Common\Exception
 */
class UnsupportedTypeException extends SpoutException
{
}
