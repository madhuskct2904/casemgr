<?php

namespace App\Library\Box\Spout\Common\Exception;

/**
 * Class SpoutException
 *
 * @package App\Library\Box\Spout\Common\Exception
 * @abstract
 */
abstract class SpoutException extends \Exception
{
}
