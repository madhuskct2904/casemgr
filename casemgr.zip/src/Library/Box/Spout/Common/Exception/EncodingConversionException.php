<?php

namespace App\Library\Box\Spout\Common\Exception;

/**
 * Class EncodingConversionException
 *
 * @api
 * @package App\Library\Box\Spout\Common\Exception
 */
class EncodingConversionException extends SpoutException
{
}
