<?php

namespace App\Library\Box\Spout\Common\Exception;

/**
 * Class InvalidArgumentException
 *
 * @api
 * @package App\Library\Box\Spout\Common\Exception
 */
class InvalidArgumentException extends SpoutException
{
}
