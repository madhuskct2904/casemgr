<?php

namespace App\Library\Box\Spout\Common\Exception;

/**
 * Class IOException
 *
 * @api
 * @package App\Library\Box\Spout\Common\Exception
 */
class IOException extends SpoutException
{
}
