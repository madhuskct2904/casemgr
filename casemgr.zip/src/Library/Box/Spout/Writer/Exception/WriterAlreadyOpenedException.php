<?php

namespace App\Library\Box\Spout\Writer\Exception;

/**
 * Class WriterAlreadyOpenedException
 *
 * @api
 * @package App\Library\Box\Spout\Writer\Exception
 */
class WriterAlreadyOpenedException extends WriterException
{
}
