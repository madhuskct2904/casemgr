<?php

namespace App\Library\Box\Spout\Writer\Exception;

/**
 * Class SheetNotFoundException
 *
 * @api
 * @package App\Library\Box\Spout\Writer\Exception
 */
class SheetNotFoundException extends WriterException
{
}
