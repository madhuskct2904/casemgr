<?php

namespace App\Library\Box\Spout\Writer\Exception;

/**
 * Class WriterNotOpenedException
 *
 * @api
 * @package App\Library\Box\Spout\Writer\Exception
 */
class WriterNotOpenedException extends WriterException
{
}
