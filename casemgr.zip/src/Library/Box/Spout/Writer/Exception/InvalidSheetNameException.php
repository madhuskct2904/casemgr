<?php

namespace App\Library\Box\Spout\Writer\Exception;

/**
 * Class InvalidSheetNameException
 *
 * @api
 * @package App\Library\Box\Spout\Writer\Exception
 */
class InvalidSheetNameException extends WriterException
{
}
