<?php

namespace App\Enum;

abstract class SystemMessageStatus extends BasicEnum
{
    const UNREAD = 'unread';
    const READ = 'read';
}
