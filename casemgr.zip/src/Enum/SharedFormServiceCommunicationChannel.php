<?php


namespace App\Enum;

class SharedFormServiceCommunicationChannel extends BasicEnum
{
    const SMS = 'sms';
    const EMAIL = 'email';
}
