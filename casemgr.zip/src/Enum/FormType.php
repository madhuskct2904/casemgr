<?php


namespace App\Enum;

abstract class FormType extends BasicEnum
{
    const FORM = 'form';
    const TEMPLATE = 'template';
}
