<?php


namespace App\Enum;

class EmailRecipientStatus extends BasicEnum
{
    const NEW = 0;
    const SENT = 1;
    const ERROR = 2;
}
