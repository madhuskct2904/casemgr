<?php


namespace App\Enum;

class EmailType extends BasicEnum
{
    const DRAFT = 0;
    const EMAIL = 1;
}
