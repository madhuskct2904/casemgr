<?php

namespace App\Enum;

abstract class ParticipantType extends BasicEnum
{
    const INDIVIDUAL = 0;
    const MEMBER = 1;
}
