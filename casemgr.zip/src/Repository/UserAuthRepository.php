<?php

namespace App\Repository;

use App\Entity\Users;

class UserAuthRepository extends \Doctrine\ORM\EntityRepository
{

}
