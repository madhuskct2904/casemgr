<?php

namespace App\Repository;

use App\EntityRepository\EntityRepository;

/**
 * Class ParticipantDirectoryColumnsRepository
 * @package App\Repository
 */
class ParticipantDirectoryColumnsRepository extends EntityRepository
{
}
