<?php


namespace App\Repository;

use Gedmo\Tree\Entity\Repository\NestedTreeRepository;

class ReportFolderRepository extends NestedTreeRepository
{
}
