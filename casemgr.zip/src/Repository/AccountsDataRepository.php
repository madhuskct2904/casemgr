<?php

namespace App\Repository;

use Doctrine\ORM\EntityRepository;

/**
 * Class AccountsDataRepository
 * @package App\Repository
 */
class AccountsDataRepository extends EntityRepository
{
}
