<?php

namespace App\Domain\FormData;

class FormDataTableException extends \Exception
{
}
