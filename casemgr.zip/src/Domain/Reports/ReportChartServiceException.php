<?php namespace App\Domain\Reports;

class ReportChartServiceException extends \Exception
{

}
