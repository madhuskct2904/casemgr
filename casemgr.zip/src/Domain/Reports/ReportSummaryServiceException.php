<?php namespace App\Domain\Reports;

class ReportSummaryServiceException extends \Exception
{

}
