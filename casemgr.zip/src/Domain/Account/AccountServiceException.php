<?php

namespace App\Domain\Account;

class AccountServiceException extends \Exception
{
}
