<?php

namespace App\Domain\SharedForms;

use Exception;

class SharedFormServiceException extends Exception
{
}
