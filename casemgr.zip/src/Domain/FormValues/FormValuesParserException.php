<?php

namespace App\Domain\FormValues;

/**
 * Class CompletedFormsTableException
 * @package App\Exception
 */
class FormValuesParserException extends \Exception
{
}
