<?php


namespace App\Domain\DataImport;

interface ImportValidatorInterface
{

}
