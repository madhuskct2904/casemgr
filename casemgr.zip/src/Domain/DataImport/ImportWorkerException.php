<?php


namespace App\Domain\DataImport;

class ImportWorkerException extends \Exception
{

}
