<?php

namespace App\Domain\DataImport;

class ImportManagerException extends \Exception
{

}
