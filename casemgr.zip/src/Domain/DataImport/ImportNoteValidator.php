<?php


namespace App\Domain\DataImport;


class ImportNoteValidator implements ImportValidatorInterface
{

}
