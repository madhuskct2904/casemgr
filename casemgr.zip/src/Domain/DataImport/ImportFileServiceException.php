<?php

namespace App\Domain\DataImport;

class ImportFileServiceException extends \Exception
{

}
