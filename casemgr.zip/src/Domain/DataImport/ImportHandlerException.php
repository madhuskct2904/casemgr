<?php

namespace App\Domain\DataImport;

class ImportHandlerException extends \Exception
{

}
