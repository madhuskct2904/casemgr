<?php

namespace App\Domain\DataImport;

class ImportCreatorException extends \Exception
{

}
