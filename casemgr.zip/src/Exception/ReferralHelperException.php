<?php


namespace App\Exception;

use Exception;

class ReferralHelperException extends Exception
{
}
