<?php

namespace App\Exception;

use Exception;

class TwilioResponseException extends Exception
{
}
