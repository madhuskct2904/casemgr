<?php
namespace App\Exception;

class ParticipantServiceException extends \Exception {

}
