<?php


namespace App\Exception;

use Exception;

/**
 * Class MassMessageServiceException
 * @package App\Exception
 */
class MassMessageServiceException extends Exception
{
}
