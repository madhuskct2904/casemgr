<?php

namespace App\Exception;

use Exception;

class SaveValuesServiceException extends Exception
{

}
