<?php


namespace App\Exception;

class ReportsFoldersServiceException extends \Exception
{
}
