<?php

namespace App\Exception;

class CloneParticipantProfileDataException extends \Exception
{
}
